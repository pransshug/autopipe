{{/* Expand chart name */}}
{{- define "pipeline-tester.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Fully qualified name */}}
{{- define "pipeline-tester.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "pipeline-tester.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/* Chart label */}}
{{- define "pipeline-tester.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Labels */}}
{{- define "pipeline-tester.labels" -}}
helm.sh/chart: {{ include "pipeline-tester.chart" . }}
{{ include "pipeline-tester.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/* Selector labels */}}
{{- define "pipeline-tester.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pipeline-tester.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/* Service account name */}}
{{- define "pipeline-tester.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "pipeline-tester.fullname" .) .Values.serviceAccount.name }}
{{- else }}
default
{{- end }}
{{- end }}

{{/* Base cluster ingress domain, derived from the VirtualService endpoint by dropping its first DNS label */}}
{{- define "pipeline-tester.baseDomain" -}}
{{- (splitn "." 2 .Values.ezua.virtualService.endpoint)._1 -}}
{{- end }}

{{/* NO_PROXY value: the configured proxy.noProxy plus a wildcard for the cluster ingress domain so
     in-cluster ingress calls bypass the corporate proxy. */}}
{{- define "pipeline-tester.noProxy" -}}
{{- $base := include "pipeline-tester.baseDomain" . -}}
{{- if $base -}}
{{- printf "%s,.%s" .Values.proxy.noProxy $base -}}
{{- else -}}
{{- .Values.proxy.noProxy -}}
{{- end -}}
{{- end }}

{{/* Docker registry auth (.dockerconfigjson content) for the private image pull secret */}}
{{- define "pipeline-tester.dockerconfigjson" -}}
{{- $reg := .Values.imageCredentials.registry -}}
{{- $usr := .Values.imageCredentials.username -}}
{{- $tok := .Values.imageCredentials.token -}}
{{- $auth := printf "%s:%s" $usr $tok | b64enc -}}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"auth\":\"%s\"}}}" $reg $usr $tok $auth -}}
{{- end }}
